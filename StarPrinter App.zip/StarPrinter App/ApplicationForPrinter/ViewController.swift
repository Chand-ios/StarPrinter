//
//  ViewController.swift
//  ApplicationForPrinter
//
//  Created by Ible on 26/10/21.
//

import UIKit

class ViewController: CommonViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tbl: UITableView!
    
    var selectedIndexPath: IndexPath!
 
    override func viewDidLoad() {
        super.viewDidLoad()
        let title: String = "ApplicationForPrinter"
        
        let version: String = String(format: "Ver.%@", Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String)
        
        self.navigationItem.title = String(format: "%@ %@", title, version)
        
        self.selectedIndexPath = nil
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tbl.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: UITableViewCell!

        if AppDelegate.settingManager.settings[0] == nil {
            let cellIdentifier: String = "UITableViewCellStyleValue1"
            
            cell = self.tbl.dequeueReusableCell(withIdentifier: cellIdentifier)
            
            if cell == nil {
                cell = UITableViewCell(style: UITableViewCell.CellStyle.value1,
                                       reuseIdentifier: cellIdentifier)
            }
            
            if cell != nil {
                cell.backgroundColor = UIColor(red: 0.8, green: 0.9, blue: 1.0, alpha: 1.0)
                
                cell      .textLabel!.text = "Unselected State"
                cell.detailTextLabel!.text = ""
                
                cell      .textLabel!.textColor = UIColor.red
                cell.detailTextLabel!.textColor = UIColor.red
                
                UIView.beginAnimations(nil, context: nil)
                
                cell      .textLabel!.alpha = 0.0
                cell.detailTextLabel!.alpha = 0.0
                
                UIView.setAnimationDelay             (0.0)                             // 0mS!!!
                UIView.setAnimationDuration          (0.6)                             // 600mS!!!
                UIView.setAnimationRepeatCount       (Float(UINT32_MAX))
                UIView.setAnimationRepeatAutoreverses(true)
                UIView.setAnimationCurve             (UIView.AnimationCurve.easeIn)
                
                cell      .textLabel!.alpha = 1.0
                cell.detailTextLabel!.alpha = 1.0
                
                UIView.commitAnimations()
                
                cell.accessoryType = UITableViewCell.AccessoryType.disclosureIndicator
                
                cell.isUserInteractionEnabled = true
            }
        }
        else {
            let currentSetting = AppDelegate.settingManager.settings[indexPath.row]!
            
            let cellIdentifier: String = "UITableViewCellStyleSubtitle"
            
            cell = self.tbl.dequeueReusableCell(withIdentifier: cellIdentifier)
            
            if cell == nil {
                cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle,
                                       reuseIdentifier: cellIdentifier)
            }
            
            cell.textLabel!.text = currentSetting.modelName
            
            if currentSetting.macAddress == "" {
                cell.detailTextLabel!.text = currentSetting.portName
            } else {
                cell.detailTextLabel!.text = "\(currentSetting.portName) (\(currentSetting.macAddress))"
            }

            cell.backgroundColor = UIColor(red: 0.8, green: 0.9, blue: 1.0, alpha: 1.0)
            cell.textLabel!.textColor = UIColor.blue
            cell.detailTextLabel!.textColor = UIColor.blue
            cell.accessoryType = .disclosureIndicator
            
            return cell
        }
        return cell!

    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let searchPortNameVC = self.storyboard?.instantiateViewController(withIdentifier: "SearchPortViewController") as! SearchPortViewController
        navigationController?.pushViewController(searchPortNameVC, animated: true)
    }

    
    @IBAction func printButtonTouchUpInside(_ sender: Any) {
        var commands: Data? = nil
        let emulation: StarIoExtEmulation = AppDelegate.getEmulation()

        commands = createBarcodeData(emulation)
        if commands != nil {
            sendCommands(commands)
        }

    }
    
    
    fileprivate func sendCommands(_ commands: Data?) {
        let portName:     String = AppDelegate.getPortName()
        let portSettings: String = AppDelegate.getPortSettings()
                
        GlobalQueueManager.shared.serialQueue.async {
            _ = Communication.sendCommands(commands,
                                           portName: portName,
                                           portSettings: portSettings,
                                           timeout: 10000,
                                           completionHandler: { (communicationResult: CommunicationResult) in
                                            DispatchQueue.main.async {
                                                self.showSimpleAlert(title: "Communication Result",
                                                                     message: Communication.getCommunicationResultMessage(communicationResult),
                                                                     buttonTitle: "OK",
                                                                     buttonStyle: .cancel)
                                                
                                            }
            })
        }
    }
    
    
     func createBarcodeData(_ emulation: StarIoExtEmulation) -> Data {
//        let otherDataUpcE:    Data = "01234500006" .data(using: String.Encoding.ascii)!
//        let otherDataUpcA:    Data = "01234567890" .data(using: String.Encoding.ascii)!
//        let otherDataJan8:    Data = "0123456"     .data(using: String.Encoding.ascii)!
//        let otherDataJan13:   Data = "012345678901".data(using: String.Encoding.ascii)!
//        let otherDataCode39:  Data = "0123456789"  .data(using: String.Encoding.ascii)!
//        let otherDataItf:     Data = "0123456789"  .data(using: String.Encoding.ascii)!
        let otherDataCode128: Data = "{BWR-1024".data(using: String.Encoding.ascii)!
//        let otherDataCode93:  Data = "0123456789"  .data(using: String.Encoding.ascii)!
//        let otherDataNw7:     Data = "A0123456789B".data(using: String.Encoding.ascii)!

         //let otherDataCode128: Data = "{B0123456789".data(using: String.Encoding.ascii)!

        let builder: ISCBBuilder = StarIoExt.createCommandBuilder(emulation)
        
        builder.beginDocument()
        
//        builder.append("*UPCE*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataUpcE,    symbology: SCBBarcodeSymbology.UPCE,    width: SCBBarcodeWidth.mode1, height: 40, hri: true)
//        builder.appendUnitFeed(32)
//        builder.append("\n*UPCA*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataUpcA,    symbology: SCBBarcodeSymbology.UPCA,    width: SCBBarcodeWidth.mode1, height: 40, hri: true)
//        builder.appendUnitFeed(32)
//        builder.append("\n*JAN8*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataJan8,    symbology: SCBBarcodeSymbology.JAN8,    width: SCBBarcodeWidth.mode1, height: 40, hri: true)
//        builder.appendUnitFeed(32)
//        builder.append("\n*JAN13*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataJan13,   symbology: SCBBarcodeSymbology.JAN13,   width: SCBBarcodeWidth.mode1, height: 40, hri: true)
//        builder.appendUnitFeed(32)
//        builder.append("\n*Code39*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataCode39,  symbology: SCBBarcodeSymbology.code39,  width: SCBBarcodeWidth.mode1, height: 40, hri: true)
//        builder.appendUnitFeed(32)
//        builder.append("\n*ITF*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataItf,     symbology: SCBBarcodeSymbology.ITF,     width: SCBBarcodeWidth.mode1, height: 40, hri: true)
//        builder.appendUnitFeed(32)
         
       // builder.append("\n*Code128*\n".data(using: String.Encoding.ascii))
        builder.appendBarcodeData(otherDataCode128, symbology: SCBBarcodeSymbology.code128, width: SCBBarcodeWidth.mode2, height: 40, hri: true)
        builder.appendUnitFeed(32)
         
//        builder.append("\n*Code93*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataCode93,  symbology: SCBBarcodeSymbology.code93,  width: SCBBarcodeWidth.mode1, height: 40, hri: true)
//        builder.appendUnitFeed(32)
//        builder.append("\n*NW7*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataNw7,     symbology: SCBBarcodeSymbology.NW7,     width: SCBBarcodeWidth.mode1, height: 40, hri: true)
//        builder.appendUnitFeed(32)

//        builder.append("*HRI:false*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataUpcE, symbology: SCBBarcodeSymbology.UPCE, width: SCBBarcodeWidth.mode1, height: 40, hri: false)
//        builder.appendUnitFeed(32)
//        builder.append("*Mode:1*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataUpcE, symbology: SCBBarcodeSymbology.UPCE, width: SCBBarcodeWidth.mode1, height: 40, hri: true)
//        builder.appendUnitFeed(32)
//        builder.append("*Mode:2*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataUpcE, symbology: SCBBarcodeSymbology.UPCE, width: SCBBarcodeWidth.mode2, height: 40, hri: true)
//        builder.appendUnitFeed(32)
//        builder.append("*Mode:3*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(otherDataUpcE, symbology: SCBBarcodeSymbology.UPCE, width: SCBBarcodeWidth.mode3, height: 40, hri: true)
//        builder.appendUnitFeed(32)

        
//        builder.append("\n*AbsolutePosition:40*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(withAbsolutePosition: otherDataUpcE, symbology: SCBBarcodeSymbology.UPCE, width: SCBBarcodeWidth.mode1, height: 40, hri: true, position: 40)
//        builder.appendUnitFeed(32)
//
//
//        builder.append("\n*Alignment:Center*\n".data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(withAlignment: otherDataUpcE, symbology: SCBBarcodeSymbology.UPCE, width: SCBBarcodeWidth.mode1, height: 40, hri: true, position: SCBAlignmentPosition.center)
//        builder.appendUnitFeed(32)
         
//        builder.append("\n*Alignment:Right*\n" .data(using: String.Encoding.ascii))
//        builder.appendBarcodeData(withAlignment: otherDataUpcE, symbology: SCBBarcodeSymbology.UPCE, width: SCBBarcodeWidth.mode1, height: 40, hri: true, position: SCBAlignmentPosition.right)
//        builder.appendUnitFeed(32)

        
        builder.appendCutPaper(SCBCutPaperAction.partialCutWithFeed)
        
        builder.endDocument()
        
        return builder.commands.copy() as! Data
    }

}

